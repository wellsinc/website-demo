import axios from 'axios';
import * as cheerio from 'cheerio';

async function test() {
  try {
    const res = await axios.get('https://www.capitoltrades.com/trades', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      }
    });
    const $ = cheerio.load(res.data);
    const rows = $('table tbody tr').slice(0, 5);
    const trades = rows.map((i, el) => {
      const tds = $(el).find('td');
      
      const official = $(tds[0]).find('.politician-name').text().trim();
      const party = $(tds[0]).find('.party').text().trim();
      const state = $(tds[0]).find('.us-state-compact').text().trim();
      
      const issuer = $(tds[1]).find('.issuer-name').text().trim();
      const ticker = $(tds[1]).find('.issuer-ticker').text().trim();
      
      const pubDate1 = $(tds[2]).find('.text-size-3').text().trim();
      const pubDate2 = $(tds[2]).find('.text-size-2').text().trim();
      const pubDate = `${pubDate1} ${pubDate2}`;
      
      const tradeDate1 = $(tds[3]).find('.text-size-3').text().trim();
      const tradeDate2 = $(tds[3]).find('.text-size-2').text().trim();
      const tradeDate = `${tradeDate1} ${tradeDate2}`;
      
      const type = $(tds[6]).find('.tx-type').text().trim();
      const size = $(tds[7]).find('.trade-size .text-size-2').text().trim();
      const price = $(tds[8]).text().trim();
      
      return { official, party, state, issuer, ticker, pubDate, tradeDate, type, size, price };
    }).get();
    
    console.log(trades);
  } catch (e: any) {
    console.error(e.message);
  }
}

test();

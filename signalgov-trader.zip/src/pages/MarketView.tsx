import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { Search, Filter, TrendingUp, TrendingDown, Activity, Maximize2, ArrowUpRight } from 'lucide-react';
import { cn } from '../lib/utils';
import { marketService } from '../services/api';

const defaultWatchlist = ['AAPL', 'MSFT', 'NVDA', 'PLTR', 'TSLA'];

export default function MarketView() {
  const [activeSymbol, setActiveSymbol] = useState('NVDA');
  const [timeframe, setTimeframe] = useState('1D');
  const [watchlist, setWatchlist] = useState<any[]>([]);
  const [stockData, setStockData] = useState<any[]>([]);
  const [activeQuote, setActiveQuote] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchWatchlist = async () => {
      try {
        const quotes = await marketService.getWatchlistQuotes(defaultWatchlist);
        setWatchlist(quotes.map((q: any) => ({
          symbol: q.symbol,
          price: q.regularMarketPrice,
          change: q.regularMarketChangePercent,
          volume: (q.regularMarketVolume / 1000000).toFixed(1) + 'M',
        })));
      } catch (error) {
        console.error('Failed to fetch watchlist:', error);
      }
    };
    fetchWatchlist();
    const interval = setInterval(fetchWatchlist, 60000); // Update every minute
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const fetchChartData = async () => {
      setLoading(true);
      try {
        const quote = await marketService.getQuote(activeSymbol);
        setActiveQuote(quote);

        // Calculate date range based on timeframe
        const end = new Date();
        const start = new Date();
        let interval = '1d';

        switch (timeframe) {
          case '1D':
            start.setDate(end.getDate() - 1);
            interval = '5m';
            break;
          case '1W':
            start.setDate(end.getDate() - 7);
            interval = '1h';
            break;
          case '1M':
            start.setMonth(end.getMonth() - 1);
            interval = '1d';
            break;
          case '3M':
            start.setMonth(end.getMonth() - 3);
            interval = '1d';
            break;
          case '1Y':
            start.setFullYear(end.getFullYear() - 1);
            interval = '1wk';
            break;
          case '5Y':
            start.setFullYear(end.getFullYear() - 5);
            interval = '1mo';
            break;
        }

        const history = await marketService.getHistory(
          activeSymbol, 
          start.toISOString().split('T')[0], 
          end.toISOString().split('T')[0], 
          interval
        );

        setStockData(history.map((d: any) => ({
          time: new Date(d.date).toLocaleDateString(undefined, { 
            month: 'short', 
            day: 'numeric',
            ...(timeframe === '1D' || timeframe === '1W' ? { hour: '2-digit', minute: '2-digit' } : {})
          }),
          price: d.close,
          volume: d.volume,
        })));
      } catch (error) {
        console.error('Failed to fetch chart data:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchChartData();
  }, [activeSymbol, timeframe]);

  return (
    <div className="h-full flex flex-col lg:flex-row gap-6 pb-24 md:pb-6">
      {/* Left Column - Watchlist */}
      <div className="w-full lg:w-80 flex flex-col gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search markets..." 
            className="w-full bg-white/5 border border-white/10 rounded-xl py-2 pl-10 pr-4 text-sm focus:outline-none focus:border-indigo-500/50 focus:bg-white/10 transition-all"
          />
        </div>

        <div className="flex-1 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-md overflow-hidden flex flex-col">
          <div className="p-4 border-b border-white/5 flex justify-between items-center bg-black/20">
            <h3 className="font-semibold">Watchlist</h3>
            <button className="p-1.5 hover:bg-white/10 rounded-lg transition-colors">
              <Filter className="w-4 h-4 text-slate-400" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {watchlist.length === 0 ? (
              <div className="p-4 text-center text-slate-400 text-sm">Loading watchlist...</div>
            ) : (
              watchlist.map((stock) => (
                <button
                  key={stock.symbol}
                  onClick={() => setActiveSymbol(stock.symbol)}
                  className={cn(
                    "w-full flex items-center justify-between p-3 rounded-xl transition-all",
                    activeSymbol === stock.symbol 
                      ? "bg-indigo-500/20 border border-indigo-500/30" 
                      : "hover:bg-white/5 border border-transparent"
                  )}
                >
                  <div className="text-left">
                    <p className="font-bold">{stock.symbol}</p>
                    <p className="text-xs text-slate-400">{stock.volume} Vol</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">${stock.price?.toFixed(2)}</p>
                    <p className={cn(
                      "text-xs font-medium flex items-center justify-end",
                      stock.change >= 0 ? "text-emerald-400" : "text-rose-400"
                    )}>
                      {stock.change >= 0 ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
                      {Math.abs(stock.change)?.toFixed(2)}%
                    </p>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Right Column - Charts */}
      <div className="flex-1 flex flex-col gap-4">
        {/* Header */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-md flex flex-wrap justify-between items-start gap-4">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <h2 className="text-3xl font-bold tracking-tight">{activeSymbol}</h2>
              <span className="px-2 py-1 rounded bg-indigo-500/20 text-indigo-400 text-xs font-bold border border-indigo-500/20">
                {activeQuote?.quoteType || 'EQUITY'}
              </span>
            </div>
            <div className="flex items-baseline gap-3">
              <span className="text-4xl font-light tracking-tight">
                ${activeQuote?.regularMarketPrice?.toFixed(2) || '---'}
              </span>
              {activeQuote && (
                <span className={cn(
                  "font-medium flex items-center text-lg",
                  activeQuote.regularMarketChange >= 0 ? "text-emerald-400" : "text-rose-400"
                )}>
                  {activeQuote.regularMarketChange >= 0 ? <ArrowUpRight className="w-5 h-5 mr-1" /> : <TrendingDown className="w-5 h-5 mr-1" />}
                  {activeQuote.regularMarketChange > 0 ? '+' : ''}{activeQuote.regularMarketChange?.toFixed(2)} ({activeQuote.regularMarketChangePercent?.toFixed(2)}%)
                </span>
              )}
            </div>
          </div>

          <div className="flex gap-2 bg-black/40 p-1 rounded-xl border border-white/5">
            {['1D', '1W', '1M', '3M', '1Y', '5Y'].map((tf) => (
              <button
                key={tf}
                onClick={() => setTimeframe(tf)}
                className={cn(
                  "px-4 py-1.5 text-sm font-medium rounded-lg transition-colors",
                  timeframe === tf ? "bg-white/10 text-white shadow-sm" : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
                )}
              >
                {tf}
              </button>
            ))}
          </div>
        </div>

        {/* Chart Area */}
        <div className="flex-1 bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-md flex flex-col min-h-[400px]">
          <div className="flex justify-between items-center mb-6">
            <div className="flex gap-2">
              <button className="px-3 py-1.5 text-xs font-medium rounded-lg bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                Price
              </button>
              <button className="px-3 py-1.5 text-xs font-medium rounded-lg hover:bg-white/10 text-slate-400 transition-colors">
                RSI
              </button>
              <button className="px-3 py-1.5 text-xs font-medium rounded-lg hover:bg-white/10 text-slate-400 transition-colors">
                MACD
              </button>
            </div>
            <button className="p-2 hover:bg-white/10 rounded-lg text-slate-400 transition-colors">
              <Maximize2 className="w-4 h-4" />
            </button>
          </div>

          {/* Main Price Chart */}
          <div className="flex-1 w-full relative">
            {loading ? (
              <div className="absolute inset-0 flex items-center justify-center text-slate-400">
                Loading chart data...
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={stockData} margin={{ top: 5, right: 0, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                  <XAxis 
                    dataKey="time" 
                    stroke="rgba(255,255,255,0.2)" 
                    fontSize={12} 
                    tickLine={false}
                    axisLine={false}
                    minTickGap={30}
                  />
                  <YAxis 
                    stroke="rgba(255,255,255,0.2)" 
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    domain={['auto', 'auto']}
                    tickFormatter={(val) => `$${val.toFixed(0)}`}
                    orientation="right"
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'rgba(15, 15, 20, 0.9)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }}
                    itemStyle={{ color: '#fff' }}
                    labelStyle={{ color: '#94a3b8', marginBottom: '4px' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="price" 
                    stroke="#34d399" 
                    strokeWidth={2}
                    dot={false}
                    activeDot={{ r: 6, fill: '#34d399', stroke: '#05050A', strokeWidth: 2 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>

          {/* Volume Chart */}
          <div className="h-24 w-full mt-4">
            {!loading && (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stockData} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                  <YAxis hide domain={[0, 'dataMax']} />
                  <Bar dataKey="volume" fill="rgba(255,255,255,0.1)" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Action Bar */}
        <div className="flex gap-4">
          <button className="flex-1 py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-600 transition-colors font-bold text-lg shadow-[0_0_20px_rgba(16,185,129,0.3)]">
            Buy {activeSymbol}
          </button>
          <button className="flex-1 py-4 rounded-2xl bg-rose-500 hover:bg-rose-600 transition-colors font-bold text-lg shadow-[0_0_20px_rgba(244,63,94,0.3)]">
            Sell {activeSymbol}
          </button>
          <button className="w-16 flex items-center justify-center rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
            <Activity className="w-6 h-6 text-indigo-400" />
          </button>
        </div>
      </div>
    </div>
  );
}

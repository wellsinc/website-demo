import React from 'react';
import { motion } from 'motion/react';
import { ArrowUpRight, ArrowDownRight, Activity, TrendingUp, AlertTriangle, ChevronRight, Landmark } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { cn } from '../lib/utils';

const portfolioData = [
  { time: '9:30', value: 124500 },
  { time: '10:30', value: 125200 },
  { time: '11:30', value: 124800 },
  { time: '12:30', value: 126100 },
  { time: '13:30', value: 125900 },
  { time: '14:30', value: 127400 },
  { time: '15:30', value: 128200 },
];

const alerts = [
  { id: 1, type: 'trigger', title: 'Rule Triggered', desc: 'NVDA trailing stop executed at $890.50', time: '2m ago', icon: Activity, color: 'text-indigo-400', bg: 'bg-indigo-500/10' },
  { id: 2, type: 'political', title: 'High Insider Overlap', desc: '4 officials bought PLTR in last 48h', time: '15m ago', icon: AlertTriangle, color: 'text-rose-400', bg: 'bg-rose-500/10' },
  { id: 3, type: 'market', title: 'Volume Spike', desc: 'TSLA trading volume 300% above avg', time: '1h ago', icon: TrendingUp, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
];

const activeRules = [
  { id: 1, symbol: 'AAPL', condition: 'Price > $180', action: 'Sell 50%', status: 'Active' },
  { id: 2, symbol: 'MSFT', condition: 'Drop > 5%', action: 'Buy $5k', status: 'Active' },
  { id: 3, symbol: 'AMD', condition: 'Trailing Stop 8%', action: 'Sell All', status: 'Active' },
];

export default function HomeDashboard() {
  return (
    <div className="space-y-6 pb-24 md:pb-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Portfolio</h1>
          <p className="text-slate-400 mt-1">Welcome back. Markets are open.</p>
        </div>
        <div className="flex gap-3">
          <button className="px-4 py-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors font-medium text-sm">
            Deposit
          </button>
          <button className="px-4 py-2 rounded-xl bg-indigo-500 hover:bg-indigo-600 transition-colors font-medium text-sm shadow-[0_0_15px_rgba(99,102,241,0.4)]">
            New Trade
          </button>
        </div>
      </div>

      {/* Main Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 blur-[80px] rounded-full pointer-events-none" />
          
          <div className="flex justify-between items-start mb-6">
            <div>
              <p className="text-slate-400 font-medium mb-1">Total Balance</p>
              <h2 className="text-4xl font-bold tracking-tight">$128,200.50</h2>
              <div className="flex items-center gap-2 mt-2">
                <span className="flex items-center text-emerald-400 bg-emerald-400/10 px-2 py-1 rounded-md text-sm font-medium">
                  <ArrowUpRight className="w-4 h-4 mr-1" />
                  +$3,700.50 (2.9%)
                </span>
                <span className="text-slate-500 text-sm">Today</span>
              </div>
            </div>
            <div className="flex bg-black/40 rounded-lg p-1 border border-white/5">
              {['1D', '1W', '1M', '3M', '1Y', 'ALL'].map((tf) => (
                <button 
                  key={tf}
                  className={cn(
                    "px-3 py-1 text-xs font-medium rounded-md transition-colors",
                    tf === '1D' ? "bg-white/10 text-white" : "text-slate-400 hover:text-slate-200"
                  )}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>

          <div className="h-[240px] w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={portfolioData} margin={{ top: 5, right: 0, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                <XAxis 
                  dataKey="time" 
                  stroke="rgba(255,255,255,0.2)" 
                  fontSize={12} 
                  tickLine={false}
                  axisLine={false}
                  dy={10}
                />
                <YAxis 
                  stroke="rgba(255,255,255,0.2)" 
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(val) => `$${(val/1000).toFixed(0)}k`}
                  domain={['dataMin - 1000', 'dataMax + 1000']}
                  dx={-10}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'rgba(15, 15, 20, 0.9)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }}
                  itemStyle={{ color: '#fff' }}
                  formatter={(value: number) => [`$${value.toLocaleString()}`, 'Value']}
                />
                <Area 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#6366f1" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorValue)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="space-y-6">
          {/* Quick Stats */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
              <p className="text-slate-400 text-sm font-medium mb-1">Buying Power</p>
              <p className="text-xl font-bold">$42,500.00</p>
            </div>
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
              <p className="text-slate-400 text-sm font-medium mb-1">Active Rules</p>
              <p className="text-xl font-bold">12</p>
            </div>
          </div>

          {/* Alerts Panel */}
          <div className="p-5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md flex-1">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg">Recent Alerts</h3>
              <button className="text-xs text-indigo-400 hover:text-indigo-300 font-medium flex items-center">
                View All <ChevronRight className="w-3 h-3 ml-1" />
              </button>
            </div>
            <div className="space-y-4">
              {alerts.map((alert) => (
                <div key={alert.id} className="flex items-start gap-3">
                  <div className={cn("p-2 rounded-lg mt-0.5", alert.bg)}>
                    <alert.icon className={cn("w-4 h-4", alert.color)} />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-200">{alert.title}</p>
                    <p className="text-xs text-slate-400 mt-0.5">{alert.desc}</p>
                    <p className="text-[10px] text-slate-500 mt-1">{alert.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Active Rules */}
        <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-semibold text-lg">Active Auto-Trades</h3>
            <button className="text-sm text-indigo-400 hover:text-indigo-300 font-medium">Manage</button>
          </div>
          <div className="space-y-3">
            {activeRules.map((rule) => (
              <div key={rule.id} className="flex items-center justify-between p-3 rounded-xl bg-black/20 border border-white/5 hover:bg-white/5 transition-colors cursor-pointer">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center font-bold text-sm">
                    {rule.symbol}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{rule.condition}</p>
                    <p className="text-xs text-slate-400">{rule.action}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
                  <span className="text-xs text-slate-400">{rule.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Political Activity Highlight */}
        <div className="p-6 rounded-2xl bg-gradient-to-br from-indigo-900/20 to-purple-900/20 border border-indigo-500/20 backdrop-blur-md relative overflow-hidden">
          <div className="absolute top-0 right-0 p-6 opacity-10">
            <Landmark className="w-32 h-32" />
          </div>
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2 py-1 rounded bg-rose-500/20 text-rose-400 text-xs font-bold uppercase tracking-wider border border-rose-500/20">
                High Activity Alert
              </span>
            </div>
            <h3 className="text-2xl font-bold mb-2">Palantir Technologies (PLTR)</h3>
            <p className="text-slate-300 text-sm mb-6 max-w-sm">
              Detected coordinated buying pattern. 6 elected officials have purchased PLTR in the last 72 hours, totaling an estimated $1.2M - $2.5M.
            </p>
            
            <div className="flex items-center gap-4">
              <button className="px-4 py-2 rounded-xl bg-indigo-500 hover:bg-indigo-600 transition-colors font-medium text-sm shadow-[0_0_15px_rgba(99,102,241,0.4)]">
                View Details
              </button>
              <button className="px-4 py-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors font-medium text-sm">
                Set Alert
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

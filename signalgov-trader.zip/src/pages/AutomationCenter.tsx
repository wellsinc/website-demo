import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Bot, Plus, Play, Pause, Settings2, Trash2, ArrowRight, Activity, Percent, DollarSign, Clock, ArrowDownRight, ArrowUpRight, Landmark } from 'lucide-react';
import { cn } from '../lib/utils';

const rules = [
  { id: 1, name: 'NVDA Trailing Stop', symbol: 'NVDA', type: 'trailing_stop', condition: 'Drop 8% from peak', action: 'Sell 100%', status: 'active', lastTriggered: 'Never' },
  { id: 2, name: 'Buy the Dip: AAPL', symbol: 'AAPL', type: 'price_drop', condition: 'Price drops below $175', action: 'Buy $5,000', status: 'active', lastTriggered: '2 days ago' },
  { id: 3, name: 'PLTR Profit Lock', symbol: 'PLTR', type: 'profit_target', condition: 'Gain > 50%', action: 'Sell 50%', status: 'paused', lastTriggered: '1 week ago' },
  { id: 4, name: 'Gov Tracker Follow', symbol: 'ANY', type: 'political_signal', condition: 'Score > 90 & 3+ Buys', action: 'Alert Only', status: 'active', lastTriggered: 'Today, 9:30 AM' },
];

const ruleTypes = [
  { id: 'price', icon: DollarSign, label: 'Price Target', desc: 'Trigger on specific price' },
  { id: 'percent', icon: Percent, label: 'Percentage Change', desc: 'Trigger on % move' },
  { id: 'trailing', icon: Activity, label: 'Trailing Stop', desc: 'Dynamic stop loss' },
  { id: 'time', icon: Clock, label: 'Time Based', desc: 'Execute at specific time' },
];

export default function AutomationCenter() {
  const [isCreating, setIsCreating] = useState(false);

  return (
    <div className="space-y-6 pb-24 md:pb-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
            <Bot className="w-8 h-8 text-indigo-400" />
            Auto-Trade Engine
          </h1>
          <p className="text-slate-400 mt-1">Create conditional rules to automate your trading strategy.</p>
        </div>
        <button 
          onClick={() => setIsCreating(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-500 hover:bg-indigo-600 transition-colors font-medium text-sm shadow-[0_0_15px_rgba(99,102,241,0.4)]"
        >
          <Plus className="w-4 h-4" />
          New Rule
        </button>
      </div>

      {isCreating ? (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-md"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold">Create New Rule</h2>
            <button 
              onClick={() => setIsCreating(false)}
              className="text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {ruleTypes.map((type) => (
              <button key={type.id} className="p-4 rounded-xl border border-white/10 bg-black/20 hover:bg-white/5 hover:border-indigo-500/50 transition-all text-left group">
                <type.icon className="w-6 h-6 text-indigo-400 mb-3 group-hover:scale-110 transition-transform" />
                <h3 className="font-semibold text-slate-200 mb-1">{type.label}</h3>
                <p className="text-xs text-slate-400">{type.desc}</p>
              </button>
            ))}
          </div>

          <div className="space-y-6 max-w-2xl">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-2">Asset Symbol</label>
                <input type="text" placeholder="e.g. AAPL" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500/50 transition-colors uppercase" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-2">Rule Name</label>
                <input type="text" placeholder="e.g. AAPL Dip Buy" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500/50 transition-colors" />
              </div>
            </div>

            <div className="p-4 rounded-xl border border-indigo-500/20 bg-indigo-500/5">
              <h4 className="font-medium text-indigo-300 mb-4 flex items-center gap-2">
                <Settings2 className="w-4 h-4" />
                Condition Configuration
              </h4>
              <div className="flex items-center gap-4">
                <select className="bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500/50 appearance-none flex-1">
                  <option>Price Drops Below</option>
                  <option>Price Rises Above</option>
                  <option>Percentage Drop</option>
                  <option>Percentage Gain</option>
                </select>
                <input type="number" placeholder="Value" className="w-32 bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500/50" />
              </div>
            </div>

            <div className="p-4 rounded-xl border border-emerald-500/20 bg-emerald-500/5">
              <h4 className="font-medium text-emerald-400 mb-4 flex items-center gap-2">
                <ArrowRight className="w-4 h-4" />
                Action to Execute
              </h4>
              <div className="flex items-center gap-4">
                <select className="bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500/50 appearance-none flex-1">
                  <option>Buy Market</option>
                  <option>Sell Market</option>
                  <option>Send Alert Only</option>
                </select>
                <div className="relative w-32">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">$</span>
                  <input type="number" placeholder="Amount" className="w-full bg-black/40 border border-white/10 rounded-xl pl-8 pr-4 py-3 text-white focus:outline-none focus:border-emerald-500/50" />
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <button 
                onClick={() => setIsCreating(false)}
                className="px-6 py-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors font-medium"
              >
                Cancel
              </button>
              <button className="px-6 py-3 rounded-xl bg-indigo-500 hover:bg-indigo-600 transition-colors font-medium shadow-[0_0_15px_rgba(99,102,241,0.4)]">
                Save & Activate Rule
              </button>
            </div>
          </div>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {rules.map((rule) => (
            <motion.div 
              key={rule.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "p-6 rounded-2xl border backdrop-blur-md flex flex-col md:flex-row md:items-center justify-between gap-6 transition-all",
                rule.status === 'active' 
                  ? "bg-white/5 border-white/10 hover:border-indigo-500/30" 
                  : "bg-black/40 border-white/5 opacity-75"
              )}
            >
              <div className="flex items-start gap-4">
                <div className={cn(
                  "w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border",
                  rule.status === 'active' ? "bg-indigo-500/20 border-indigo-500/30 text-indigo-400" : "bg-white/5 border-white/10 text-slate-500"
                )}>
                  {rule.type === 'trailing_stop' && <Activity className="w-6 h-6" />}
                  {rule.type === 'price_drop' && <ArrowDownRight className="w-6 h-6" />}
                  {rule.type === 'profit_target' && <ArrowUpRight className="w-6 h-6" />}
                  {rule.type === 'political_signal' && <Landmark className="w-6 h-6" />}
                </div>
                
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="font-bold text-lg text-slate-200">{rule.name}</h3>
                    <span className={cn(
                      "px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider border",
                      rule.status === 'active' ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" : "bg-slate-500/10 text-slate-400 border-slate-500/20"
                    )}>
                      {rule.status}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm">
                    <span className="text-slate-400 flex items-center gap-1">
                      <span className="font-mono text-xs bg-white/10 px-1.5 py-0.5 rounded text-slate-300">{rule.symbol}</span>
                    </span>
                    <span className="text-slate-500">•</span>
                    <span className="text-slate-300">If: <span className="font-medium text-indigo-300">{rule.condition}</span></span>
                    <span className="text-slate-500">•</span>
                    <span className="text-slate-300">Then: <span className="font-medium text-emerald-400">{rule.action}</span></span>
                  </div>
                  <p className="text-xs text-slate-500 mt-2">Last triggered: {rule.lastTriggered}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0 border-t md:border-t-0 border-white/5 pt-4 md:pt-0">
                <button className={cn(
                  "p-2.5 rounded-lg border transition-colors flex items-center justify-center",
                  rule.status === 'active' 
                    ? "bg-amber-500/10 border-amber-500/20 text-amber-400 hover:bg-amber-500/20" 
                    : "bg-emerald-500/10 border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/20"
                )} title={rule.status === 'active' ? "Pause Rule" : "Activate Rule"}>
                  {rule.status === 'active' ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                </button>
                <button className="p-2.5 rounded-lg bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-white/10 transition-colors" title="Edit Rule">
                  <Settings2 className="w-5 h-5" />
                </button>
                <button className="p-2.5 rounded-lg bg-white/5 border border-white/10 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 hover:border-rose-500/30 transition-colors" title="Delete Rule">
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}

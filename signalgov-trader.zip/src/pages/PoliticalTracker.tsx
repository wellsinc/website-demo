import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Landmark, Search, Filter, AlertTriangle, ArrowUpRight, ArrowDownRight, Users, ShieldAlert, BarChart3 } from 'lucide-react';
import { cn } from '../lib/utils';
import { politicalService } from '../services/api';

const trending = [
  { symbol: 'PLTR', score: 98, trend: 'up', officials: 6, volume: '$2.5M' },
  { symbol: 'NVDA', score: 94, trend: 'up', officials: 4, volume: '$1.8M' },
  { symbol: 'LMT', score: 89, trend: 'up', officials: 3, volume: '$950K' },
  { symbol: 'PFE', score: 82, trend: 'down', officials: 5, volume: '$1.2M' },
];

export default function PoliticalTracker() {
  const [activeTab, setActiveTab] = useState('feed');
  const [trades, setTrades] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTrades = async () => {
      try {
        const data = await politicalService.getTrades();
        setTrades(data);
      } catch (error) {
        console.error('Failed to fetch political trades:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchTrades();
  }, []);

  return (
    <div className="space-y-6 pb-24 md:pb-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
            <Landmark className="w-8 h-8 text-indigo-400" />
            Gov Tracker
          </h1>
          <p className="text-slate-400 mt-1">Monitor congressional trading activity and cross-reference signals.</p>
        </div>
        <div className="flex gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search official or ticker..." 
              className="w-64 bg-white/5 border border-white/10 rounded-xl py-2 pl-10 pr-4 text-sm focus:outline-none focus:border-indigo-500/50 focus:bg-white/10 transition-all"
            />
          </div>
          <button className="p-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
            <Filter className="w-5 h-5 text-slate-400" />
          </button>
        </div>
      </div>

      {/* Intelligence Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Cross-Reference Score */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-gradient-to-br from-indigo-900/30 to-black border border-indigo-500/20 backdrop-blur-md relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 blur-[80px] rounded-full pointer-events-none" />
          
          <div className="flex items-center gap-2 mb-4">
            <ShieldAlert className="w-5 h-5 text-indigo-400" />
            <h3 className="font-semibold text-lg">Intelligence Engine</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-black/40 border border-white/5">
              <p className="text-slate-400 text-sm font-medium mb-1">Bipartisan Buys</p>
              <p className="text-3xl font-bold text-emerald-400">12</p>
              <p className="text-xs text-slate-500 mt-1">Last 30 days</p>
            </div>
            <div className="p-4 rounded-xl bg-black/40 border border-white/5">
              <p className="text-slate-400 text-sm font-medium mb-1">Mass Sell-Offs</p>
              <p className="text-3xl font-bold text-rose-400">3</p>
              <p className="text-xs text-slate-500 mt-1">High conviction alerts</p>
            </div>
            <div className="p-4 rounded-xl bg-black/40 border border-white/5">
              <p className="text-slate-400 text-sm font-medium mb-1">Total Volume Tracked</p>
              <p className="text-3xl font-bold text-indigo-400">$42.5M</p>
              <p className="text-xs text-slate-500 mt-1">Estimated value</p>
            </div>
          </div>

          <div className="mt-6 p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-start gap-4">
            <div className="p-2 bg-indigo-500/20 rounded-lg shrink-0">
              <BarChart3 className="w-6 h-6 text-indigo-400" />
            </div>
            <div>
              <h4 className="font-semibold text-indigo-300 mb-1">AI Insight</h4>
              <p className="text-sm text-indigo-200/80 leading-relaxed">
                Unusual concentration detected in cybersecurity sector. 8 officials across 4 committees have initiated positions in PANW and CRWD prior to upcoming defense budget hearings. Bipartisan overlap score is exceptionally high (92/100).
              </p>
            </div>
          </div>
        </div>

        {/* Trending Stocks */}
        <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Users className="w-5 h-5 text-indigo-400" />
              Most Traded
            </h3>
            <span className="text-xs text-slate-400 bg-white/10 px-2 py-1 rounded-md">7 Days</span>
          </div>
          
          <div className="flex-1 space-y-4">
            {trending.map((item, i) => (
              <div key={item.symbol} className="flex items-center justify-between group">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center font-bold text-sm border border-white/10 group-hover:border-indigo-500/50 transition-colors">
                    {i + 1}
                  </div>
                  <div>
                    <p className="font-bold">{item.symbol}</p>
                    <p className="text-xs text-slate-400">{item.officials} officials</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center justify-end gap-1">
                    <span className={cn(
                      "text-sm font-bold",
                      item.score > 90 ? "text-rose-400" : "text-emerald-400"
                    )}>
                      {item.score}
                    </span>
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider">Score</span>
                  </div>
                  <p className="text-xs text-slate-400">{item.volume}</p>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 transition-colors text-sm font-medium text-slate-300">
            View Full Leaderboard
          </button>
        </div>
      </div>

      {/* Trade Feed */}
      <div className="bg-white/5 border border-white/10 rounded-2xl backdrop-blur-md overflow-hidden">
        <div className="border-b border-white/5 p-4 flex gap-6">
          <button 
            onClick={() => setActiveTab('feed')}
            className={cn(
              "font-medium text-sm transition-colors relative pb-4 -mb-4",
              activeTab === 'feed' ? "text-indigo-400" : "text-slate-400 hover:text-slate-200"
            )}
          >
            Live Trade Feed
            {activeTab === 'feed' && (
              <motion.div layoutId="tab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-400 rounded-t-full" />
            )}
          </button>
          <button 
            onClick={() => setActiveTab('alerts')}
            className={cn(
              "font-medium text-sm transition-colors relative pb-4 -mb-4",
              activeTab === 'alerts' ? "text-indigo-400" : "text-slate-400 hover:text-slate-200"
            )}
          >
            High Conviction Alerts
            {activeTab === 'alerts' && (
              <motion.div layoutId="tab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-400 rounded-t-full" />
            )}
          </button>
        </div>

        <div className="overflow-x-auto">
          {loading ? (
            <div className="p-8 text-center text-slate-400">Loading latest disclosures...</div>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/5 text-xs uppercase tracking-wider text-slate-500 bg-black/20">
                  <th className="p-4 font-medium">Official</th>
                  <th className="p-4 font-medium">Ticker</th>
                  <th className="p-4 font-medium">Type</th>
                  <th className="p-4 font-medium">Amount Range</th>
                  <th className="p-4 font-medium">Date Filed</th>
                  <th className="p-4 font-medium text-right">Activity Score</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {trades.map((trade) => (
                  <tr key={trade.id} className="hover:bg-white/5 transition-colors group cursor-pointer">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className={cn(
                          "w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border",
                          trade.party === 'D' ? "bg-blue-500/10 border-blue-500/30 text-blue-400" : 
                          trade.party === 'R' ? "bg-red-500/10 border-red-500/30 text-red-400" : 
                          "bg-slate-500/10 border-slate-500/30 text-slate-400"
                        )}>
                          {trade.party}
                        </div>
                        <div>
                          <p className="font-medium text-slate-200 group-hover:text-white transition-colors">{trade.official}</p>
                          <p className="text-xs text-slate-500">{trade.state}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="font-bold text-slate-200">{trade.symbol}</span>
                      <p className="text-xs text-slate-500 truncate max-w-[150px]">{trade.issuer}</p>
                    </td>
                    <td className="p-4">
                      <span className={cn(
                        "inline-flex items-center px-2 py-1 rounded text-xs font-bold uppercase tracking-wider",
                        trade.type === 'Buy' ? "bg-emerald-500/10 text-emerald-400" : "bg-rose-500/10 text-rose-400"
                      )}>
                        {trade.type === 'Buy' ? <ArrowUpRight className="w-3 h-3 mr-1" /> : <ArrowDownRight className="w-3 h-3 mr-1" />}
                        {trade.type}
                      </span>
                    </td>
                    <td className="p-4 text-slate-300 text-sm">{trade.amount}</td>
                    <td className="p-4 text-slate-400 text-sm">{trade.pubDate}</td>
                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <div className="w-16 h-1.5 bg-white/10 rounded-full overflow-hidden">
                          <div 
                            className={cn(
                              "h-full rounded-full",
                              trade.score > 80 ? "bg-rose-500" : trade.score > 50 ? "bg-amber-500" : "bg-emerald-500"
                            )}
                            style={{ width: `${trade.score}%` }}
                          />
                        </div>
                        <span className="text-sm font-bold w-6">{trade.score}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        {!loading && (
          <div className="p-4 border-t border-white/5 bg-black/20 text-center">
            <button className="text-sm text-indigo-400 hover:text-indigo-300 font-medium transition-colors">
              Load More Disclosures
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

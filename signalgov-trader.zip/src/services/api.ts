import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
});

export const marketService = {
  getQuote: async (symbol: string) => {
    const response = await api.get(`/market/quote/${symbol}`);
    return response.data;
  },
  getHistory: async (symbol: string, period1?: string, period2?: string, interval?: string) => {
    const params = new URLSearchParams();
    if (period1) params.append('period1', period1);
    if (period2) params.append('period2', period2);
    if (interval) params.append('interval', interval);
    
    const response = await api.get(`/market/history/${symbol}?${params.toString()}`);
    return response.data;
  },
  getWatchlistQuotes: async (symbols: string[]) => {
    const response = await api.get(`/market/quotes?symbols=${symbols.join(',')}`);
    return response.data;
  }
};

export const politicalService = {
  getTrades: async () => {
    const response = await api.get('/political/trades');
    return response.data;
  }
};

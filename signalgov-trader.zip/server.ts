import express from 'express';
import { createServer as createViteServer } from 'vite';
import cors from 'cors';
import yahooFinance from 'yahoo-finance2';
import axios from 'axios';
import * as cheerio from 'cheerio';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  // --- API Routes ---

  // 1. Yahoo Finance API
  
  // Get real-time quote for a symbol
  app.get('/api/market/quote/:symbol', async (req, res) => {
    try {
      const { symbol } = req.params;
      const quote = await yahooFinance.quote(symbol);
      res.json(quote);
    } catch (error: any) {
      console.error('Error fetching quote:', error.message);
      res.status(500).json({ error: 'Failed to fetch quote' });
    }
  });

  // Get historical data for a symbol
  app.get('/api/market/history/:symbol', async (req, res) => {
    try {
      const { symbol } = req.params;
      const { period1, period2, interval } = req.query;
      
      const queryOptions: any = {
        period1: period1 ? String(period1) : '2023-01-01',
        interval: interval ? String(interval) : '1d',
      };
      
      if (period2) {
        queryOptions.period2 = String(period2);
      }

      const result = await yahooFinance.historical(symbol, queryOptions);
      res.json(result);
    } catch (error: any) {
      console.error('Error fetching history:', error.message);
      res.status(500).json({ error: 'Failed to fetch historical data' });
    }
  });

  // Get multiple quotes for watchlist
  app.get('/api/market/quotes', async (req, res) => {
    try {
      const symbols = req.query.symbols as string;
      if (!symbols) {
        return res.status(400).json({ error: 'Symbols parameter is required' });
      }
      const symbolArray = symbols.split(',');
      const quotes = await Promise.all(
        symbolArray.map(async (sym) => {
          try {
            return await yahooFinance.quote(sym);
          } catch (e) {
            return null;
          }
        })
      );
      res.json(quotes.filter(Boolean));
    } catch (error: any) {
      console.error('Error fetching quotes:', error.message);
      res.status(500).json({ error: 'Failed to fetch quotes' });
    }
  });

  // 2. Capitol Trades Scraper API
  
  app.get('/api/political/trades', async (req, res) => {
    try {
      const response = await axios.get('https://www.capitoltrades.com/trades', {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
      });
      
      const $ = cheerio.load(response.data);
      const rows = $('table tbody tr').slice(0, 50); // Get latest 50 trades
      
      const trades = rows.map((i, el) => {
        const tds = $(el).find('td');
        
        const official = $(tds[0]).find('.politician-name').text().trim();
        const party = $(tds[0]).find('.party').text().trim();
        const state = $(tds[0]).find('.us-state-compact').text().trim();
        
        const issuer = $(tds[1]).find('.issuer-name').text().trim();
        const tickerRaw = $(tds[1]).find('.issuer-ticker').text().trim();
        // Remove ':US' from ticker if present
        const ticker = tickerRaw.replace(':US', '');
        
        const pubDate1 = $(tds[2]).find('.text-size-3').text().trim();
        const pubDate2 = $(tds[2]).find('.text-size-2').text().trim();
        const pubDate = `${pubDate1} ${pubDate2}`;
        
        const tradeDate1 = $(tds[3]).find('.text-size-3').text().trim();
        const tradeDate2 = $(tds[3]).find('.text-size-2').text().trim();
        const tradeDate = `${tradeDate1} ${tradeDate2}`;
        
        const type = $(tds[6]).find('.tx-type').text().trim();
        const size = $(tds[7]).find('.trade-size .text-size-2').text().trim();
        const price = $(tds[8]).text().trim();
        
        // Calculate a mock score based on some rules (since we don't have historical overlap context easily here)
        // In a real app, this would be calculated by the cross-reference engine in the DB
        let score = 50;
        if (type.toLowerCase() === 'buy') score += 20;
        if (size.includes('M')) score += 20;
        if (size.includes('500K')) score += 10;
        
        return { 
          id: i.toString(),
          official, 
          party: party === 'Democrat' ? 'D' : party === 'Republican' ? 'R' : 'I', 
          state, 
          issuer, 
          symbol: ticker !== 'N/A' ? ticker : issuer, 
          pubDate, 
          date: tradeDate, 
          type: type.charAt(0).toUpperCase() + type.slice(1), 
          amount: size, 
          price,
          score
        };
      }).get();
      
      res.json(trades);
    } catch (error: any) {
      console.error('Error fetching political trades:', error.message);
      res.status(500).json({ error: 'Failed to fetch political trades' });
    }
  });

  // --- Vite Middleware ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
